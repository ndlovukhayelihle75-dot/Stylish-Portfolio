email = "ndlovukhayelihle@gmail.com"
password ="4321"
print("Login")
verifyemail = input("Enter your email: ")
if verifyemail == email:
    print("Email is correct")
else: print("Email is incorrect")
verifypassword = input("Enter your password:")
if verifypassword == password:
    print("Password is correct")
else: print("Password is incorrect")