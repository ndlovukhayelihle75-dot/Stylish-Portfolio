First_number = float(input("Enter the first number:"))
Second_number = float(input("Enter the Second number:"))
operator = input("+, -, *, /")
if operator == ("+"):
    print(First_number + Second_number)
elif operator == ("-"):
    print(First_number - Second_number)
elif operator == ("*"):
    print(First_number * Second_number)
elif operator == ("/"):
    print(First_number / Second_number)
    if First_number == 0 or Second_number == 0:
        print = First_number / Second_number
    else:
        print("You cannot divide by zero")
else:
        print("Results")